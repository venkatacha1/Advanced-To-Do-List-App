document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("taskForm");
  const container = document.getElementById("taskContainer");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const task = {
      title: taskTitle.value,
      category: taskCategory.value,
      dueDate: dueDate.value,
      priority: priority.value,
      completed: false
    };

    await fetch("/api/add", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(task)
    });

    form.reset();
    loadTasks();
  });

  async function loadTasks() {
    const res = await fetch("/api/tasks");
    const tasks = await res.json();
    container.innerHTML = "";

    const grouped = tasks.reduce((acc, task) => {
      acc[task.category] = acc[task.category] || [];
      acc[task.category].push(task);
      return acc;
    }, {});

    for (let [cat, tasks] of Object.entries(grouped)) {
      const card = document.createElement("div");
      
      card.classList.add("task-card");
      card.className = "mb-4";
      const completedCount = tasks.filter(t => t.completed).length;
      const progress = Math.round((completedCount / tasks.length) * 100);

      card.innerHTML = `
        <h4>${cat} (${completedCount}/${tasks.length})</h4>
        <div class="progress mb-3"><div class="progress-bar" role="progressbar" style="width: ${progress}%;"></div></div>
        <div class="list-group">
          ${tasks.map(task => `
            <label class="list-group-item d-flex justify-content-between align-items-center task-card ${task.completed ? 'task-completed' : ''}" data-priority="${task.priority}">
              <div class="d-flex align-items-center">
                <input type="checkbox" class="form-check-input me-2" onchange="toggleTask(${task.id})" ${task.completed ? 'checked' : ''}/>
                ${task.title} <small class="text-muted">[${task.dueDate}]</small>
              </div>
              <div>
                <span class="badge bg-${getBadge(task.priority)} me-2">${task.priority}</span>
                <button class="btn btn-sm btn-outline-danger" onclick="deleteTask(${task.id})">Delete</button>
              </div>
            </label>
          `).join("")}
        </div>
      `;
      container.appendChild(card);
    }
  }

  window.toggleTask = async function (id) {
    await fetch(`/api/toggle/${id}`, { method: "PUT" });
    loadTasks();
  };

  window.deleteTask = async function (id) {
    if (confirm("Are you sure you want to delete this task?")) {
      await fetch(`/api/delete/${id}`, { method: "DELETE" });
      loadTasks();
    }
  };

  function getBadge(priority) {
    return priority === "High" ? "danger" : priority === "Medium" ? "warning" : "success";
  }

  async function checkNotifications() {
    const res = await fetch("/api/tasks");
    const tasks = await res.json();
    const now = new Date();
    tasks.forEach(task => {
      const due = new Date(task.dueDate);
      const diff = (due - now) / (1000 * 60);
      if (diff > 0 && diff < 60 && !task.completed) {
        notify(`Task "${task.title}" is due soon!`);
      }
    });
  }

  function notify(msg) {
    if (Notification.permission === "granted") {
      new Notification("Reminder", { body: msg });
    } else if (Notification.permission !== "denied") {
      Notification.requestPermission().then(permission => {
        if (permission === "granted") notify(msg);
      });
    }
  }

  loadTasks();
  setInterval(checkNotifications, 30000); // every 30 sec
});
