const express = require("express");
const router = express.Router();
const db = require("./db");

// Add a new task
router.post("/add", (req, res) => {
  const { title, category, dueDate, priority } = req.body;
  db.query("INSERT INTO tasks SET ?", { title, category, dueDate, priority, completed: false }, err => {
    if (err) throw err;
    res.sendStatus(200);
  });
});

// Get all tasks
router.get("/tasks", (req, res) => {
  db.query("SELECT * FROM tasks", (err, result) => {
    if (err) throw err;
    res.json(result);
  });
});

// Toggle task completion status
router.put("/toggle/:id", (req, res) => {
  db.query("UPDATE tasks SET completed = NOT completed WHERE id = ?", [req.params.id], err => {
    if (err) throw err;
    res.sendStatus(200);
  });
});

// Delete a task
router.delete("/delete/:id", (req, res) => {
  db.query("DELETE FROM tasks WHERE id = ?", [req.params.id], err => {
    if (err) throw err;
    res.sendStatus(200);
  });
});

module.exports = router;
