const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const path = require("path");

const app = express();
const routes = require("./server/routes");
const db = require("./server/db"); // Ensure this exists and connects to your DB

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, "public")));
app.use("/api", routes);

// Debug route to check database manually
app.get("/debug", (req, res) => {
  db.query("SELECT * FROM tasks", (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    console.log("DEBUG tasks:", rows);
    res.json(rows);
  });
});

// Start server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
